# convert rainfall data
##zz<-file("rain_sta08057320_1973_0603.txt","r")
rm(list=ls()) # clear environment
fileinput <- "unit_sta08057320_1973_0603.txt"
detach(zz)
zz<-read.table(fileinput,header=TRUE)
attach(zz)
howManyrows <- length(DATE_TIME)
elapsed_time <- seq(0,HOURS_PASSED[howManyrows],0.25) # choose time step 1 = 1 hour
object <- approx(HOURS_PASSED, ACCUM_RUNOFF, elapsed_time, method="linear", n=50,yleft=0, yright=ACCUM_RUNOFF[howManyrows], rule=1, f=0)
# plot data to check processing
plot(object$x,object$y,xlab="Elapsed Time (hrs)",ylab="Runoff (watershed inches)")
# send to output file
outfile <- str_replace(fileinput,"unit","u15m")
howManyrows <- length(object$x)
for (irow in 1:howManyrows){
  write(c(object$x[irow],object$y[irow]),outfile,append=TRUE,sep=",")
  }
