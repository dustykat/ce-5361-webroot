# Numerical planimeter
# Integrates plane area defined by x,y pairs.
# First and last pair must be same and supplied
# prototype function
area_panel <-function(x1,x2,y1,y2){
  area_panel <- (x2 - x1)*(0.5*(y2 - y1) + y1)
  return(area_panel)
}
# read in data file
fileToRead <- "Reference.txt"
zz <- read.table(fileToRead,header=FALSE,sep="") #space delimited ASCII
#
howMany <- length(zz$V1)
accumulated_area <- 0.0
# compute panel areas
for( index in 1:(howMany-1)){
  accumulated_area <- accumulated_area + area_panel(zz$V1[index],zz$V1[index+1],zz$V2[index],zz$V2[index+1])
  }
message("Reference Area = ",accumulated_area,"  Data units")
refArea<-accumulated_area
fileToRead <- "Eden.txt"
zz <- read.table(fileToRead,header=FALSE,sep="") #space delimited ASCII
#
howMany <- length(zz$V1)
accumulated_area <- 0.0
# compute panel areas
for( index in 1:(howMany-1)){
  accumulated_area <- accumulated_area + area_panel(zz$V1[index],zz$V1[index+1],zz$V2[index],zz$V2[index+1])
}
message("Measured Area = ",accumulated_area,"  Data units")
mesArea <- accumulated_area
message("Measured/Reference Area Ratio = ",mesArea/refArea," Ratio Units")